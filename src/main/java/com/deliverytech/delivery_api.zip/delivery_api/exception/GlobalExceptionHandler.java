package com.deliverytech.delivery_api.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(RuntimeException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public String tratarRuntimeException(RuntimeException ex) {
        return ex.getMessage();
    }
}