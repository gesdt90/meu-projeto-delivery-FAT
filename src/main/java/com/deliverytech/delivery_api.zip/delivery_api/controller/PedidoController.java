package com.deliverytech.delivery_api.controller;

import org.springframework.web.bind.annotation.*;

import com.deliverytech.delivery_api.model.Pedido;
import com.deliverytech.delivery_api.service.PedidoService;
import java.util.List;

@RestController
@RequestMapping("/pedidos")

public class PedidoController {

    private final PedidoService service;

    public PedidoController(PedidoService service) {
        this.service = service;
    }

    @PostMapping
    public Pedido criarPedido(@RequestBody Pedido pedido) {
        return service.processarPedido(pedido);
    }
    @GetMapping
    public List<Pedido> listarPedidos() {
    return service.listarTodos();
    }
}